#include <vector>   // Pour utiliser std::vector
#include <string>   // Pour utiliser std::string
#include <iostream> // Pour l'exemple d'affichage

#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

#include "pack.h"

std::vector<std::string> ensFiles = {
"BMP_NCATR.png",
"BMP_NCHAR.png",
"BMP_NCORD.png",
"BMP_NEXTCONQ.png",
"CONQUEST.png",
"PALETTE_WORLD.png",
"PIECE_DUNE_001.png",
"PIECE_DUNE_002.png",
"PIECE_DUNE_003.png",
"PIECE_DUNE_004.png",
"PIECE_DUNE_005.png",
"PIECE_DUNE_006.png",
"PIECE_DUNE_007.png",
"PIECE_DUNE_008.png",
"PIECE_DUNE_009.png",
"PIECE_DUNE_010.png",
"PIECE_DUNE_011.png",
"PIECE_DUNE_012.png",
"PIECE_DUNE_013.png",
"PIECE_DUNE_014.png",
"PIECE_DUNE_015.png",
"PIECE_DUNE_016.png",
"PIECE_DUNE_017.png",
"PIECE_DUNE_018.png",
"PIECE_DUNE_019.png",
"PIECE_DUNE_020.png",
"PIECE_DUNE_021.png",
"PIECE_DUNE_022.png",
"PIECE_DUNE_023.png",
"PIECE_DUNE_024.png",
"PIECE_DUNE_025.png",
"PIECE_DUNE_026.png",
"PIECE_DUNE_027.png",
"WORLD_DUNE.png",
"WORLD_DUNE_CLICK.png",
"WORLD_DUNE_REGIONS.png"
};


int main(int argc, char ** argv)
{
    // First we create a pak file from scratch
        // write pak file.
    	WriterPack test("sdl_world.dat");
        //
        for (const auto &file : ensFiles) {
            // remove the extension from the file name
            std::string fileId = file.substr(0, file.find_last_of('.'));
            // add the file to the pack

            if (!test.addFile(file, fileId)) {
                std::cerr << "Failed to add file: " << file << std::endl;
            }
        }
        //
        test.writePackFilesOnDisk();

        test.displayPackFile();
    
        return 0;
}
