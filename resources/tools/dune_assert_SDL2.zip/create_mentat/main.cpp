#include <vector>   // Pour utiliser std::vector
#include <string>   // Pour utiliser std::string
#include <iostream> // Pour l'exemple d'affichage

#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

#include "pack.h"

std::vector<std::string> mentatFiles = {
"ATR_EYES01.png",
"ATR_EYES02.png",
"ATR_EYES03.png",
"ATR_EYES04.png",
"ATR_EYES05.png",
"ATR_MOUTH01.png",
"ATR_MOUTH02.png",
"ATR_MOUTH03.png",
"ATR_MOUTH04.png",
"ATR_MOUTH05.png",
"BEN_EYES01.png",
"BEN_EYES02.png",
"BEN_EYES03.png",
"BEN_EYES04.png",
"BEN_EYES05.png",
"BEN_MOUTH01.png",
"BEN_MOUTH02.png",
"BEN_MOUTH03.png",
"BEN_MOUTH04.png",
"BEN_MOUTH05.png",
"BTN_NO.png",
"BTN_PROCEED.png",
"BTN_REPEAT.png",
"BTN_YES.png",
"HAR_EYES01.png",
"HAR_EYES02.png",
"HAR_EYES03.png",
"HAR_EYES04.png",
"HAR_EYES05.png",
"HAR_MOUTH01.png",
"HAR_MOUTH02.png",
"HAR_MOUTH03.png",
"HAR_MOUTH04.png",
"HAR_MOUTH05.png",
"HEN_HARKONNEN.png",
"MEN_WISH.png",
"MENTAT.png",
"MENTATA.png",
"MENTATH.png",
"MENTATM.png",
"MENTATO.png",
"ORD_EYES01.png",
"ORD_EYES02.png",
"ORD_EYES03.png",
"ORD_EYES04.png",
"ORD_EYES05.png",
"ORD_MOUTH01.png",
"ORD_MOUTH02.png",
"ORD_MOUTH03.png",
"ORD_MOUTH04.png",
"ORD_MOUTH05.png"
};


int main(int argc, char ** argv)
{
    // First we create a pak file from scratch
        // write pak file.
    	WriterPack test("sdl_mentat.dat");
        //
        for (const auto &file : mentatFiles) {
            // remove the extension from the file name
            std::string fileId = file.substr(0, file.find_last_of('.'));
            // add the file to the pack

            if (!test.addFile(file, fileId)) {
                std::cerr << "Failed to add file: " << file << std::endl;
            }
        }
        //
        test.writePackFilesOnDisk();

        test.displayPackFile();
    
        return 0;
}
