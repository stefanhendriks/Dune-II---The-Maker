from PIL import Image

# Charger l'image
img = Image.open("OBJECT_DEADINF01.png")

# Vérifier que l'image est bien en mode P
if img.mode != 'P':
    raise ValueError("L'image doit être en mode 'P' (palettisée)")

# Convertir l'image en données modifiables
pixels = img.load()
palette = list(img.getpalette())
width, height = img.size

# Remplacer les pixels de l'indice 1 par ceux de l'indice 0
for y in range(height):
    for x in range(width):
        if pixels[x, y] == 1:
            pixels[x, y] = 232

for i in range(5):
    print(pixels[i,0])

for i in range(3*5):
    print(palette[i])
    
# Sauvegarder l'image avec transparence mise à jour
#img.save("BUILD_WINDTRAP_3.png", transparency=232)

