from PIL import Image

# Charger l'image
img = Image.open("OBJECT_DEADINF02.png")

# Vérifier que l'image est bien en mode P
if img.mode != 'P':
    raise ValueError("L'image doit être en mode 'P' (palettisée)")

# Convertir l'image en données modifiables
pixels = img.getdata()
palette = list(img.getpalette())
width, height = img.size

# Remplacer les pixels de l'indice 1 par ceux de l'indice 0
modified_pixel_count = 0
new_pixel_indices = []
for index in list(pixels):
    #print(index, end = ' ')
    if index == 223:
        new_pixel_indices.append(232)
        modified_pixel_count += 1
    else:
        new_pixel_indices.append(index)
            
output_img = Image.new('P', img.size)
output_img.putdata(new_pixel_indices)
output_img.putpalette(palette)

print("modifié :",modified_pixel_count)

# Sauvegarder l'image avec transparence mise à jour
output_img.info['transparency'] =232
output_img.save("OBJECT_DEADINF02.png", transparency=232)

