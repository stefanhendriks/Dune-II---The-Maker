import os
from PIL import Image

def convert_to_black_and_white(image_path, output_path, target_color=(255, 0, 255), tolerance=20):
    """
    Ouvre une image, la convertit en noir et blanc selon une couleur cible :
    si un pixel est proche de la couleur cible, il devient blanc (255,255,255),
    sinon il devient noir (0,0,0). Sauvegarde l'image en BMP.

    Args:
        image_path (str): Chemin vers l'image d'entrée.
        output_path (str): Chemin où sauvegarder l'image modifiée en BMP.
        target_color (tuple): La couleur (R, G, B) à considérer comme "proche" du blanc.
        tolerance (int): La tolérance pour déterminer si une couleur est "proche" de la couleur cible.
                         Plus la valeur est élevée, plus de couleurs seront considérées comme proches.
    """
    try:
        # 1. Ouvrir l'image
        img = Image.open(image_path)
        print(f"Image '{image_path}' ouverte avec succès. Mode : {img.mode}, Dimensions : {img.size}")

        # Assurez-vous que l'image est en mode RVB pour pouvoir manipuler les pixels directement
        if img.mode != 'RGB':
            img = img.convert('RGB')
            print(f"Image convertie en mode '{img.mode}'.")

        # Créer une nouvelle image en mode RVB pour les pixels noir et blanc
        # Cela garantit que même si l'image originale était en mode 'P',
        # la sortie sera une image RVB binaire (noir ou blanc) sans palette.
        output_img = Image.new('RGBA', img.size)

        pixels = img.load()         # Charge les données de pixels de l'image d'entrée
        output_pixels = output_img.load() # Charge les données de pixels de l'image de sortie

        # Définir les couleurs de sortie
        blanc = (255, 255, 255,255)
        noir = (0, 0, 0,255)

        # 2. Parcourir chaque pixel de l'image
        width, height = img.size
        for x in range(width):
            for y in range(height):
                r, g, b = pixels[x, y]

                # Calculer la "distance" entre le pixel actuel et la couleur cible
                # On utilise la distance euclidienne simplifiée (somme des différences absolues)
                # ou la distance euclidienne classique pour une meilleure précision.
                # Ici, j'utilise la somme des différences absolues pour la simplicité.
                diff_r = abs(r - target_color[0])
                diff_g = abs(g - target_color[1])
                diff_b = abs(b - target_color[2])

                # Si la couleur est "proche" de la couleur cible
                if diff_r <= tolerance and diff_g <= tolerance and diff_b <= tolerance:
                    output_pixels[x, y] = blanc
                else:
                    output_pixels[x, y] = noir

        # 3. Sauvegarder l'image modifiée en BMP
        output_img.save(output_path)
        print(f"Image convertie sauvegardée sous '{output_path}'.")

    except FileNotFoundError:
        print(f"Erreur : Le fichier '{image_path}' n'a pas été trouvé.")
    except Exception as e:
        print(f"Une erreur inattendue est survenue : {e}")


# Spécifie la couleur cible (magenta dans votre cas) et une tolérance
target_color_for_white = (255, 0, 255) # Magenta
color_tolerance = 30 # Ajustez cette valeur si nécessaire pour inclure plus ou moins de nuances


repertoire_cible = "."  # Le répertoire actuel

# contenu = os.listdir(repertoire_cible)
# print(f"Contenu du répertoire '{repertoire_cible}':")
# for element in contenu:
#             # Vous pouvez ajouter une logique ici si vous voulez distinguer les fichiers des répertoires
#             # Par exemple, pour lister uniquement les fichiers :
#     chemin_complet = os.path.join(repertoire_cible, element)
#     if os.path.isdir(chemin_complet):
#         print(f"  Répertoire : {element}")
#     elif os.path.isfile(chemin_complet):
#         print(f"  Fichier : {element}")
#         if "SHADOW" in element:
#             print(f"  Fichier bmp : {element}")
#             out = element[:-4]+".png"
#             convert_to_black_and_white(element, out, target_color=target_color_for_white, tolerance=color_tolerance)

# --- Utilisation du script ---
if __name__ == "__main__":
    input_image = "BUILD_LIGHTFACTORY_SHADOW.bmp"  # Remplace par le chemin de ton image BMP
    output_image = "BUILD_LIGHTFACTORY_SHADOW.png" # Chemin pour sauvegarder l'image noir et blanc en BMP
    # Spécifie la couleur cible (magenta dans votre cas) et une tolérance
    target_color_for_white = (255, 0, 255) # Magenta
    color_tolerance = 30 # Ajustez cette valeur si nécessaire pour inclure plus ou moins de nuances
    # Exécuter la fonction de conversion
    convert_to_black_and_white(input_image, output_image, target_color=target_color_for_white, tolerance=color_tolerance)
