#include <vector>   // Pour utiliser std::vector
#include <string>   // Pour utiliser std::string
#include <iostream> // Pour l'exemple d'affichage

#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

#include "pack.h"

std::vector<std::string> glxAudioFiles = {
"MIDI_ATTACK01.mid",
"MIDI_ATTACK02.mid",
"MIDI_ATTACK03.mid",
"MIDI_ATTACK04.mid",
"MIDI_ATTACK05.mid",
"MIDI_ATTACK06.mid",
"MIDI_BUILDING01.mid",
"MIDI_BUILDING02.mid",
"MIDI_BUILDING03.mid",
"MIDI_BUILDING04.mid",
"MIDI_BUILDING05.mid",
"MIDI_BUILDING06.mid",
"MIDI_BUILDING07.mid",
"MIDI_BUILDING08.mid",
"MIDI_BUILDING09.mid",
"MIDI_LOSE1.mid",
"MIDI_LOSE2.mid",
"MIDI_LOSE3.mid",
"MIDI_MENTAT_ATR.mid",
"MIDI_MENTAT_HAR.mid",
"MIDI_MENTAT_ORD.mid",
"MIDI_MENU.mid",
"MIDI_SCENARIO.mid",
"MIDI_WIN01.mid",
"MIDI_WIN02.mid",
"MIDI_WIN03.mid",
"SOUND_ACKNOWLEDGED.wav",
"SOUND_AFFIRMATIVE2.wav",
"SOUND_AFFIRMATIVE.wav",
"SOUND_ATR_S1.wav",
"SOUND_ATR_S2.wav",
"SOUND_ATR_S3.wav",
"SOUND_ATR_S4.wav",
"SOUND_ATR_S5.wav",
"SOUND_ATREIDES.wav",
"SOUND_BUTTON.wav",
"SOUND_CREDIT_DOWN.wav",
"SOUND_CREDIT_UP.wav",
"SOUND_CRUMBLE01.wav",
"SOUND_CRUMBLE02.wav",
"SOUND_DIE01.wav",
"SOUND_DIE02.wav",
"SOUND_DIE03.wav",
"SOUND_DIE04.wav",
"SOUND_DIE05.wav",
"SOUND_EXPL_ROCKET.wav",
"SOUND_EXPL_ROCKET_SAND.wav",
"SOUND_GAS.wav",
"SOUND_GUNTURRET.wav",
"SOUND_GUN.wav",
"SOUND_HAR_S1.wav",
"SOUND_HAR_S2.wav",
"SOUND_HAR_S3.wav",
"SOUND_HAR_S4.wav",
"SOUND_HAR_S5.wav",
"SOUND_HARKONNEN.wav",
"SOUND_MACHINEGUN.wav",
"SOUND_MOVINGOUT2.wav",
"SOUND_MOVINGOUT.wav",
"SOUND_ORD_S1.wav",
"SOUND_ORD_S2.wav",
"SOUND_ORD_S3.wav",
"SOUND_ORD_S4.wav",
"SOUND_ORD_S5.wav",
"SOUND_ORDOS.wav",
"SOUND_PLACE.wav",
"SOUND_RADAR.wav",
"SOUND_REPORTING.wav",
"SOUND_ROCKET_SMALL.wav",
"SOUND_ROCKET.wav",
"SOUND_SHIMMER.wav",
"SOUND_SQUISH.wav",
"SOUND_TANKDIE2.wav",
"SOUND_TANKDIE.wav",
"SOUND_TANK.wav",
"SOUND_TRIKEDIE.wav",
"SOUND_VOICE_01_ATR.wav",
"SOUND_VOICE_01_HAR.wav",
"SOUND_VOICE_01_ORD.wav",
"SOUND_VOICE_02_ATR.wav",
"SOUND_VOICE_02_HAR.wav",
"SOUND_VOICE_02_ORD.wav",
"SOUND_VOICE_03_ATR.wav",
"SOUND_VOICE_03_HAR.wav",
"SOUND_VOICE_03_ORD.wav",
"SOUND_VOICE_04_ATR.wav",
"SOUND_VOICE_04_HAR.wav",
"SOUND_VOICE_04_ORD.wav",
"SOUND_VOICE_05_ATR.wav",
"SOUND_VOICE_05_HAR.wav",
"SOUND_VOICE_05_ORD.wav",
"SOUND_VOICE_06_ATR.wav",
"SOUND_VOICE_06_HAR.wav",
"SOUND_VOICE_06_ORD.wav",
"SOUND_VOICE_07_ATR.wav",
"SOUND_VOICE_07_HAR.wav",
"SOUND_VOICE_07_ORD.wav",
"SOUND_VOICE_08_ATR.wav",
"SOUND_VOICE_08_HAR.wav",
"SOUND_VOICE_08_ORD.wav",
"SOUND_VOICE_09_ATR.wav",
"SOUND_VOICE_09_HAR.wav",
"SOUND_VOICE_09_ORD.wav",
"SOUND_VOICE_10_ATR.wav",
"SOUND_VOICE_10_HAR.wav",
"SOUND_VOICE_10_ORD.wav",
"SOUND_WORM.wav",
"SOUND_YESSIR.wav"};


int main(int argc, char ** argv)
{
    // First we create a pak file from scratch
        // write pak file.
    	WriterPack test("sdl_audio.dat");
        //
        for (const auto &audioFile : glxAudioFiles) {
            // remove the extension from the file name
            std::string fileId = audioFile.substr(0, audioFile.find_last_of('.'));
            // add the file to the pack

            if (!test.addFile(audioFile, fileId)) {
                std::cerr << "Failed to add file: " << audioFile << std::endl;
            }
        }
        //
        test.writePackFilesOnDisk();

        test.displayPackFile();
    
        return 0;
}
