from PIL import Image
import os

def process_image_with_transparency(image_path, output_path, transparent_color=(0, 0, 0), palette_swap_enabled=False):
    """
    Ouvre une image BMP 8 bits, définit une couleur de la palette comme transparente,
    et sauvegarde l'image en PNG avec la même palette. Peut également inverser des blocs de palette.

    Args:
        image_path (str): Chemin vers l'image BMP 8 bits d'entrée.
        output_path (str): Chemin où sauvegarder l'image modifiée (doit être un chemin .png).
        transparent_color (tuple): La couleur (R, G, B) à rendre transparente. Par défaut à (0, 0, 0) (noir).
        palette_swap_enabled (bool): Si True, effectue l'échange de blocs de palette.
    """
    try:
        # 1. Ouvrir l'image
        img = Image.open(image_path)

        # Vérifier que l'image est bien en mode 'P' (Palette)
        if img.mode != 'P':
            print(f"Erreur : L'image '{image_path}' n'est pas en mode 'P' (Palette). Son mode est '{img.mode}'.")
            print("Ce script est conçu pour les images BMP 8 bits indexées.")
            return

        print(f"Image '{image_path}' ouverte avec succès. Mode : {img.mode}, Dimensions : {img.size}")

        # 2. Récupérer la palette actuelle
        current_palette = list(img.getpalette())

        # Trouver l'indice de la couleur à rendre transparente
        transparent_color_rgb = transparent_color
        transparent_index = -1
        for i in range(0, len(current_palette), 3):
            r = current_palette[i]
            g = current_palette[i+1]
            b = current_palette[i+2]
            if (r, g, b) == transparent_color_rgb:
                transparent_index = i // 3
                break

        if transparent_index == -1:
            print(f"Avertissement : La couleur {transparent_color_rgb} n'a pas été trouvée dans la palette.")
        else:
            print(f"La couleur {transparent_color_rgb} (noir) a été trouvée à l'index de palette : {transparent_index}")

        if palette_swap_enabled:
            # Code pour l'échange de palette (conservé de votre script original)
            source_start_idx = 176
            source_end_idx = 182 # Inclus
            dest_start_idx = 144
            dest_end_idx = 150   # Inclus

            pal_source_start = source_start_idx * 3
            pal_source_end = (source_end_idx * 3) + 3
            for i in range(143,144+8+1):
                print(current_palette[3*i], current_palette[3*i+1],current_palette[3*i+2] )
            pal_dest_start = dest_start_idx * 3
            pal_dest_end = (dest_end_idx * 3) + 3

            if len(current_palette) < pal_source_end or len(current_palette) < pal_dest_end:
                print(f"Erreur : La palette de l'image est trop petite ({len(current_palette)} valeurs) pour les indices demandés.")
                print(f"Nécessite une palette d'au moins {max(pal_source_end, pal_dest_end)} valeurs.")
                return

            if (pal_source_end - pal_source_start) != (pal_dest_end - pal_dest_start):
                print("Erreur : Les tailles des blocs source et destination ne correspondent pas.")
                print(f"Bloc source : {source_start_idx}-{source_end_idx} ({pal_source_end - pal_source_start} valeurs)")
                print(f"Bloc destination : {dest_start_idx}-{dest_end_idx} ({pal_dest_end - pal_dest_start} valeurs)")
                return

            source_block_colors = current_palette[pal_source_start:pal_source_end]
            print(f"Extrait le bloc source (indices {source_start_idx}-{source_end_idx}) : {source_block_colors[:6]}... (premières 2 couleurs)")
            current_palette[pal_dest_start:pal_dest_end] = source_block_colors
            print(f"Bloc de palette des indices {source_start_idx}-{source_end_idx} copié vers {dest_start_idx}-{dest_end_idx}.")
            img.putpalette(current_palette) # Apply updated palette if swap happened

        # 3. Sauvegarder l'image modifiée en PNG avec transparence
        # Pour les images en mode 'P', Pillow permet de spécifier un indice de palette
        # qui sera traité comme transparent lors de la sauvegarde en PNG.
        if transparent_index != -1:
            # The 'transparency' argument tells Pillow which color index in the palette
            # should be considered transparent when saving to PNG.
            img.save(output_path, transparency=transparent_index) #
            print(f"Image modifiée sauvegardée sous '{output_path}' avec la nouvelle palette et la couleur noire rendue transparente.")
        else:
            img.save(output_path)
            print(f"Image modifiée sauvegardée sous '{output_path}' avec la nouvelle palette (pas de transparence définie).")


    except FileNotFoundError:
        print(f"Erreur : Le fichier '{image_path}' n'a pas été trouvé.")
    except Exception as e:
        print(f"Une erreur inattendue est survenue : {e}")

# --- Utilisation du script ---
if __name__ == "__main__":
    input_image = "input.bmp"  # Remplace par le chemin de ton image BMP 8 bits
    output_image = "output.png" # Chemin pour sauvegarder l'image modifiée en PNG

    # Exécuter la fonction pour définir le noir comme transparent et sauvegarder en PNG
    # Si tu veux aussi l'échange de palette, change palette_swap_enabled=True
    process_image_with_transparency(input_image, output_image, transparent_color=(0, 0, 0), palette_swap_enabled=False)