import os
from PIL import Image

def convert_image_to_png_with_specific_transparency(input_image_path, output_png_path, transparent_color=(255, 0, 255)):
    """
    Charge une image de n'importe quel format, la convertit en PNG,
    en rendant une couleur spécifique transparente.

    Args:
        input_image_path (str): Chemin vers l'image d'entrée (peut être JPG, BMP, etc.).
        output_png_path (str): Chemin où sauvegarder l'image en format PNG.
        transparent_color (tuple): La couleur (R, G, B) à rendre transparente (par défaut 255, 0, 255 - magenta).
    """
    try:
        # 1. Ouvrir l'image
        img = Image.open(input_image_path)
        print(f"Image '{input_image_path}' ouverte avec succès. Mode : {img.mode}, Dimensions : {img.size}")

        # 2. Convertir l'image en mode 'RGBA'
        # Le mode 'RGBA' (Rouge, Vert, Bleu, Alpha) est nécessaire pour gérer la transparence.
        # Si l'image est déjà en 'RGBA' ou 'LA' (luminosité avec alpha), elle sera conservée.
        # Si elle est en 'P' (palettisée) ou 'RGB', un canal alpha sera ajouté.
        if img.mode != 'RGBA':
            img = img.convert('RGBA')
            print(f"Image convertie en mode 'RGBA' pour ajouter un canal alpha.")

        # 3. Récupérer les données de pixels
        data = img.getdata()

        new_data = []
        modified_pixels_count = 0
        # La couleur transparente est (R, G, B, A) où A est le canal alpha (0 = transparent, 255 = opaque)
        transparent_rgba = transparent_color + (255,) # Ajoute un alpha opaque initial pour la comparaison

        # 4. Parcourir les pixels et définir la transparence
        for item in data:
            # Pour chaque pixel (R, G, B, A)
            if transparent_rgba[0]-item[0]<2  and transparent_rgba[1] - item[1] <2 and transparent_rgba[2] - item[2] < 2:
                # Si la couleur correspond à la couleur cible (ignorant l'alpha existant pour la comparaison)
                new_data.append((0, 0, 0, 0)) # Définir l'alpha à 0 (transparent)
                modified_pixels_count += 1
            else:
                new_data.append(item) # Conserver le pixel tel quel (y compris son alpha si déjà présent)

        print(f"Nombre de pixels modifiés pour être transparents : {modified_pixels_count}")

        # 5. Mettre à jour les données de pixels de l'image
        img.putdata(new_data)

        # 6. Sauvegarder l'image en PNG
        # Pillow sauvegardera automatiquement l'alpha channel dans le PNG car l'image est en mode 'RGBA'.
        img.save(output_png_path)
        print(f"Image sauvegardée sous '{output_png_path}' avec la couleur {transparent_color} rendue transparente.")

    except FileNotFoundError:
        print(f"Erreur : Le fichier '{input_image_path}' n'a pas été trouvé.")
    except Exception as e:
        print(f"Une erreur inattendue est survenue : {e}")



repertoire_cible = "."  # Le répertoire actuel

# # Pour lister tous les fichiers .txt de manière récursive (Python 3.5+)
# print(f"\nFichiers .txt (récursif) dans '{repertoire_cible}':")
# try:
#     fichiers_txt_recursive = glob.glob(os.path.join(repertoire_cible, "**", "*.txt"), recursive=True)
#     for fichier in fichiers_txt_recursive:
#         print(fichier)
# except TypeError:
#     print("La recherche récursive avec glob.glob nécessite Python 3.5 ou une version ultérieure.")


# Couleur magenta (255, 0, 255) à rendre transparente
transparent_magenta = (255, 0, 255)


contenu = os.listdir(repertoire_cible)
print(f"Contenu du répertoire '{repertoire_cible}':")
for element in contenu:
            # Vous pouvez ajouter une logique ici si vous voulez distinguer les fichiers des répertoires
            # Par exemple, pour lister uniquement les fichiers :
    chemin_complet = os.path.join(repertoire_cible, element)
    if os.path.isdir(chemin_complet):
        print(f"  Répertoire : {element}")
    elif os.path.isfile(chemin_complet):
        print(f"  Fichier : {element}")
        if element[-4:] ==".bmp":
            print(f"  Fichier bmp : {element}")
            out = "./new/"+element[:-4]+".png"
            convert_image_to_png_with_specific_transparency(element, out, transparent_color=transparent_magenta)
