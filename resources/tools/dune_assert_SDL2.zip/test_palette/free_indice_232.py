from PIL import Image

def swap_pixel_palette_index(image_path, output_path, old_index=232, new_index=255):
    """
    Ouvre une image palettisée, parcourt ses pixels et remplace toutes les
    occurrences d'un ancien indice de palette par un nouvel indice de palette.
    Sauvegarde l'image modifiée, en conservant la palette d'origine.

    Args:
        image_path (str): Chemin vers l'image d'entrée (doit être une image palettisée).
        output_path (str): Chemin où sauvegarder l'image modifiée.
        old_index (int): L'indice de palette à rechercher et à remplacer.
        new_index (int): L'indice de palette par lequel remplacer.
    """
    try:
        # 1. Ouvrir l'image
        img = Image.open(image_path)
        print(f"Image '{image_path}' ouverte avec succès. Mode : {img.mode}, Dimensions : {img.size}")

        # Vérifier que l'image est bien en mode 'P' (Palette)
        if img.mode != 'P':
            print(f"Erreur : L'image '{image_path}' n'est pas en mode 'P' (Palette). Son mode est '{img.mode}'.")
            print("Ce script est conçu pour les images avec une palette (mode 'P').")
            return

        # Vérifier que les indices sont valides pour une palette 8 bits (0-255)
        if not (0 <= old_index <= 255 and 0 <= new_index <= 255):
            print("Erreur : Les indices de palette doivent être entre 0 et 255 pour une image 8 bits.")
            return

        # 2. Obtenir les données de pixels (indices)
        # getdata() retourne une séquence des indices de palette pour chaque pixel
        pixel_indices = list(img.getdata())
        print(f"Nombre de pixels dans l'image : {len(pixel_indices)}")

        # 3. Parcourir et modifier les indices des pixels
        modified_count = 0
        new_pixel_indices = []
        for index in pixel_indices:
            if index == old_index:
                new_pixel_indices.append(new_index)
                modified_count += 1
            else:
                new_pixel_indices.append(index)

        print(f"Nombre de pixels modifiés de l'indice {old_index} à l'indice {new_index} : {modified_count}")

        if modified_count == 0:
            print(f"Aucun pixel utilisant l'indice {old_index} n'a été trouvé. Aucune modification de pixel effectuée.")

        # 4. Créer une nouvelle image avec les indices de pixels modifiés
        # La palette d'origine est automatiquement copiée si on ne la change pas
        output_img = Image.new('P', img.size)
        output_img.putdata(new_pixel_indices)

        # Copier la palette de l'image originale vers la nouvelle image
        # Cela garantit que la palette (les couleurs RVB associées aux indices) reste la même
        output_img.putpalette(img.getpalette())

        # Si l'image originale avait une information de transparence, la copier aussi
        if 'transparency' in img.info:
            output_img.info['transparency'] = img.info['transparency']
            print(f"Information de transparence ({img.info['transparency']}) copiée de l'image originale.")
        
        # Si le nouvel index de palette est l'ancien index de transparence, la transparence sera conservée.
        # Sinon, l'ancien index de transparence ne sera plus transparent sauf s'il est maintenant l'index 255.
        # Si l'indice 255 doit devenir le nouvel indice de transparence si le 232 était le transparent
        # cette partie doit être gérée si vous voulez que l'indice 255 *devienne* transparent.
        # Pour ce script simple, la transparence est copiée telle quelle. Si l'indice 232 était transparent,
        # et que vous voulez que l'indice 255 le devienne, il faudrait ajouter une logique ici.
        # Par exemple:
        # if img.info.get('transparency') == old_index:
        #    output_img.info['transparency'] = new_index
        #    print(f"Ancien indice de transparence {old_index} remplacé par le nouvel indice de transparence {new_index}.")


        # 5. Sauvegarder l'image modifiée
        output_img.save(output_path)
        print(f"Image modifiée sauvegardée sous '{output_path}'.")

    except FileNotFoundError:
        print(f"Erreur : Le fichier '{image_path}' n'a pas été trouvé.")
    except Exception as e:
        print(f"Une erreur inattendue est survenue : {e}")

# --- Utilisation du script ---
if __name__ == "__main__":
    input_image_file = "input.bmp" # Remplacez par le chemin de votre image PNG 8 bits palettisée
    output_image_file = "input_modified.png" # Chemin pour sauvegarder l'image modifiée

    # Indice 232 sera remplacé par l'indice 255
    swap_pixel_palette_index(input_image_file, output_image_file, old_index=232, new_index=255)