from PIL import Image

def apply_shadow_mask(palette_image_path, shadow_mask_path, output_path):
    """
    Applique un masque d'ombre noir et blanc à une image 8 bits palettisée.
    Pour chaque pixel noir dans l'image masque, le pixel correspondant dans l'image
    palettisée sera modifié pour pointer vers l'indice 0 de sa palette.

    Args:
        palette_image_path (str): Chemin vers l'image 8 bits palettisée d'entrée.
        shadow_mask_path (str): Chemin vers l'image masque noir et blanc.
        output_path (str): Chemin où sauvegarder l'image résultante.
    """
    try:
        # 1. Ouvrir les images d'entrée
        img_palette = Image.open(palette_image_path)
        img_mask = Image.open(shadow_mask_path)

        print(f"Image palettisée '{palette_image_path}' ouverte. Mode : {img_palette.mode}, Dimensions : {img_palette.size}")
        print(f"Image masque '{shadow_mask_path}' ouverte. Mode : {img_mask.mode}, Dimensions : {img_mask.size}")

        # Vérifier que l'image principale est bien en mode 'P' (Palette)
        if img_palette.mode != 'P':
            print(f"Erreur : L'image '{palette_image_path}' n'est pas en mode 'P' (Palette). Son mode est '{img_palette.mode}'.")
            print("Ce script est conçu pour les images avec une palette (mode 'P').")
            return

        # Assurez-vous que les images ont les mêmes dimensions
        if img_palette.size != img_mask.size:
            print("Erreur : Les dimensions des deux images ne correspondent pas.")
            print(f"Image palettisée : {img_palette.size}, Image masque : {img_mask.size}")
            return

        # Assurez-vous que le masque est bien en noir et blanc (convertissez-le si nécessaire)
        # Le mode '1' est un mode binaire où le noir est 0 et le blanc est 255.
        # C'est idéal pour un masque.
        if img_mask.mode != '1':
            img_mask = img_mask.convert('1')
            print(f"Image masque convertie en mode binaire (1).")

        # 2. Obtenir les données de pixels des deux images
        # Pour l'image palettisée, on obtient les indices de palette
        pixels_palette_indices = list(img_palette.getdata())
        # Pour le masque, on obtient les valeurs 0 (noir) ou 255 (blanc)
        pixels_mask_values = list(img_mask.getdata())

        print(f"Nombre de pixels dans l'image palettisée : {len(pixels_palette_indices)}")
        print(f"Nombre de pixels dans l'image masque : {len(pixels_mask_values)}")

        # 3. Créer une nouvelle liste d'indices de pixels pour l'image de sortie
        new_pixel_indices = []
        modified_count = 0
        target_index_for_black = 0 # L'indice 0 de la palette

        # Parcourir tous les pixels en parallèle
        for i in range(len(pixels_palette_indices)):
            mask_pixel_value = pixels_mask_values[i]

            if mask_pixel_value == 0:  # Si le pixel du masque est noir
                new_pixel_indices.append(target_index_for_black)
                modified_count += 1
            else: # Si le pixel du masque est blanc, conserver l'indice original
                new_pixel_indices.append(pixels_palette_indices[i])

        print(f"Nombre de pixels modifiés pour pointer vers l'indice {target_index_for_black} : {modified_count}")

        if modified_count == 0:
            print(f"Aucun pixel noir trouvé dans le masque. Aucune modification des pixels de l'image principale.")

        # 4. Créer une nouvelle image avec les indices de pixels modifiés
        output_img = Image.new('P', img_palette.size)
        output_img.putdata(new_pixel_indices)

        # 5. Copier la palette de l'image originale vers la nouvelle image
        # La palette elle-même n'est PAS modifiée, seule l'utilisation de ses indices change.
        output_img.putpalette(img_palette.getpalette())

        # 6. Copier l'information de transparence de l'image originale (si elle existe)
        if 'transparency' in img_palette.info:
            output_img.info['transparency'] = img_palette.info['transparency']
            print(f"Information de transparence ({img_palette.info['transparency']}) copiée de l'image originale.")


        # 7. Sauvegarder l'image résultante
        # Le format de sauvegarde est déduit de l'extension du chemin de sortie.
        # Si vous voulez un PNG avec transparence, assurez-vous que output_path est un .png
        # et que l'indice 0 de votre palette est bien la couleur que vous voulez transparente
        # (si vous avez utilisé un script précédent pour cela).
        # Si l'indice 0 doit devenir transparent, vous devriez ajouter:
        # output_img.save(output_path, transparency=0)
        # Mais le script actuel se contente de copier la transparence existante.
        output_img.save(output_path)
        print(f"Image fusionnée sauvegardée sous '{output_path}'.")

    except FileNotFoundError:
        print(f"Erreur : Un des fichiers n'a pas été trouvé. Vérifiez les chemins :")
        print(f" - Image palettisée : '{palette_image_path}'")
        print(f" - Masque N&B : '{shadow_mask_path}'")
    except Exception as e:
        print(f"Une erreur inattendue est survenue : {e}")


listBuilding = []

# --- Utilisation du script ---
for elt in listBuilding:
    # Remplacez ces chemins par vos fichiers réels
    input_palette_image = elt[0]  # Votre image 8 bits avec palette (ex: sortie du 1er script)
    input_shadow_mask = elt[1] # Votre image masque noir et blanc (ex: sortie du 2ème script)
    output_final_image = "new/"+elt[0] # L'image de sortie (vous pouvez choisir .bmp, .png, etc.)

    apply_shadow_mask(input_palette_image, input_shadow_mask, output_final_image)

