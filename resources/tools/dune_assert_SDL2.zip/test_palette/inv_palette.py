from PIL import Image
import os

def swap_palette_blocks(image_path, output_path):
    """
    Ouvre une image BMP 8 bits, inverse deux blocs de sa palette (144-150 et 160-166),
    puis enregistre l'image avec la nouvelle palette.

    Args:
        image_path (str): Chemin vers l'image BMP 8 bits d'entrée.
        output_path (str): Chemin où sauvegarder l'image modifiée.
    """
    try:
        # 1. Ouvrir l'image
        img = Image.open(image_path)

        # Vérifier que l'image est bien en mode 'P' (Palette)
        if img.mode != 'P':
            print(f"Erreur : L'image '{image_path}' n'est pas en mode 'P' (Palette). Son mode est '{img.mode}'.")
            print("Ce script est conçu pour les images BMP 8 bits indexées.")
            return

        print(f"Image '{image_path}' ouverte avec succès. Mode : {img.mode}, Dimensions : {img.size}")

  # 2. Récupérer la palette actuelle
        # getpalette() retourne une liste d'entiers (R, G, B, R, G, B, ...)
        current_palette = list(img.getpalette())

        # Définir les indices sources et de destination 160 a 166 pour Atreides 176 à 182 pour Ordos et -1 à 5 pour harkonnen 
        #source_start_idx = 160
        #source_end_idx = 166 # Inclus
        source_start_idx = 176
        source_end_idx = 182 # Inclus
        dest_start_idx = 144
        dest_end_idx = 150   # Inclus

        # Calculer les positions de début et fin dans la liste de la palette (chaque couleur = 3 valeurs)
        pal_source_start = source_start_idx * 3
        pal_source_end = (source_end_idx * 3) + 3 # +3 car slice exclut la fin
        for i in range(143,144+8+1):
            print(current_palette[3*i], current_palette[3*i+1],current_palette[3*i+2] )
        pal_dest_start = dest_start_idx * 3
        pal_dest_end = (dest_end_idx * 3) + 3

        # Vérifier si la palette est suffisamment grande pour les indices source et destination
        if len(current_palette) < pal_source_end or len(current_palette) < pal_dest_end:
            print(f"Erreur : La palette de l'image est trop petite ({len(current_palette)} valeurs) pour les indices demandés.")
            print(f"Nécessite une palette d'au moins {max(pal_source_end, pal_dest_end)} valeurs.")
            return

        # Vérifier que la taille des blocs est identique pour une copie exacte
        if (pal_source_end - pal_source_start) != (pal_dest_end - pal_dest_start):
            print("Erreur : Les tailles des blocs source et destination ne correspondent pas.")
            print(f"Bloc source : {source_start_idx}-{source_end_idx} ({pal_source_end - pal_source_start} valeurs)")
            print(f"Bloc destination : {dest_start_idx}-{dest_end_idx} ({pal_dest_end - pal_dest_start} valeurs)")
            return

        # 3. Extraire le bloc de couleurs source
        source_block_colors = current_palette[pal_source_start:pal_source_end]
        #source_block_colors = [240,240,240,240,240,200,240,240,160,240,240,140,240,240,90,240,240,60,240,240,30]

        print(f"Extrait le bloc source (indices {source_start_idx}-{source_end_idx}) : {source_block_colors[:6]}... (premières 2 couleurs)")

        # 4. Copier le bloc source vers la position de destination
        current_palette[pal_dest_start:pal_dest_end] = source_block_colors

        print(f"Bloc de palette des indices {source_start_idx}-{source_end_idx} copié vers {dest_start_idx}-{dest_end_idx}.")

        # 5. Appliquer la nouvelle palette à l'image
        img.putpalette(current_palette)

        # 6. Sauvegarder l'image modifiée
        img.save(output_path)
        print(f"Image modifiée sauvegardée sous '{output_path}' avec la nouvelle palette.")

    except FileNotFoundError:
        print(f"Erreur : Le fichier '{image_path}' n'a pas été trouvé.")
    except Exception as e:
        print(f"Une erreur inattendue est survenue : {e}")

# --- Utilisation du script ---
if __name__ == "__main__":
    input_image = "input.bmp"  # Remplace par le chemin de ton image BMP 8 bits
    output_image = "output.bmp" # Chemin pour sauvegarder l'image modifiée

    # Exécuter la fonction d'échange de palette
    swap_palette_blocks(input_image, output_image)
