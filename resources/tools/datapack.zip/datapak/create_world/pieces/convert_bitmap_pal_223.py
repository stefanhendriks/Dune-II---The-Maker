import os
from PIL import Image

def process_image_for_transparency_and_index_swap(image_path, output_path, old_pixel_index=0, new_pixel_index=223):
    """
    Ouvre une image palettisée, modifie les pixels utilisant 'old_pixel_index' pour qu'ils utilisent 'new_pixel_index'.
    Puis, définit la couleur à 'new_pixel_index' dans la palette à (0,0,0,255) (noir transparent)
    et spécifie que cet indice doit être transparent lors de la sauvegarde en PNG.
    """
    try:
        # 1. Ouvrir l'image
        img = Image.open(image_path)
        print(f"Image '{image_path}' ouverte avec succès. Mode : {img.mode}, Dimensions : {img.size}")

        # Vérifier que l'image est bien en mode 'P' (Palette)
        if img.mode != 'P':
            print(f"Erreur : L'image '{image_path}' n'est pas en mode 'P' (Palette). Son mode est '{img.mode}'.")
            print("Ce script est conçu pour les images avec une palette (mode 'P').")
            return

        # Vérifier que les indices sont valides pour une palette 8 bits (0-255)
        if not (0 <= old_pixel_index <= 255 and 0 <= new_pixel_index <= 255):
            print("Erreur : Les indices de palette doivent être entre 0 et 255 pour une image 8 bits.")
            return

        # 2. Récupérer la palette actuelle
        current_palette = list(img.getpalette())

        # S'assurer que la palette a au moins 256 entrées si le nouvel_indice est 223
        # La palette PIL est une liste de 768 valeurs (256 * 3 pour R, G, B)
        # Si la palette est plus petite, il faut la "remplir" jusqu'à 256 couleurs
        if len(current_palette) < 256 * 3:
            # On remplit avec du noir opaque si nécessaire, jusqu'à 256 couleurs
            while len(current_palette) < 256 * 3:
                current_palette.extend([0, 0, 0])
            print(f"Palette étendue à {len(current_palette) // 3} couleurs pour inclure l'indice {new_pixel_index}.")

        # 3. Modifier la couleur à new_pixel_index dans la palette
        # Nous voulons que l'indice 223 soit la couleur (0,0,0) et soit transparent.
        # Pillow gère la transparence d'une couleur palettisée pour le PNG via l'argument transparency lors de la sauvegarde,
        # pas en modifiant la palette elle-même avec un canal alpha. La palette reste RGB.
        palette_index_for_color = new_pixel_index * 3
        current_palette[palette_index_for_color] = 0   # Rouge
        current_palette[palette_index_for_color + 1] = 0 # Vert
        current_palette[palette_index_for_color + 2] = 0 # Bleu
        print(f"La couleur à l'indice {new_pixel_index} de la palette a été définie sur (0,0,0).")

        # 4. Obtenir les données de pixels et les modifier
        pixel_indices = list(img.getdata())
        print(f"Nombre de pixels dans l'image : {len(pixel_indices)}")

        modified_pixel_count = 0
        new_pixel_indices = []
        for index in pixel_indices:
            if index == old_pixel_index:
                new_pixel_indices.append(new_pixel_index)
                modified_pixel_count += 1
            else:
                new_pixel_indices.append(index)

        print(f"Nombre de pixels utilisant l'indice {old_pixel_index} et modifiés vers l'indice {new_pixel_index} : {modified_pixel_count}")
        if modified_pixel_count == 0:
            print(f"Aucun pixel utilisant l'indice {old_pixel_index} n'a été trouvé. Aucune modification de pixel effectuée.")


        # 5. Créer une nouvelle image avec les indices de pixels modifiés
        output_img = Image.new('P', img.size)
        output_img.putdata(new_pixel_indices)

        # Appliquer la palette modifiée (y compris la couleur noire à l'indice 223)
        output_img.putpalette(current_palette)

        # 6. Sauvegarder l'image modifiée en PNG avec la transparence à l'indice 223
        # Pillow utilise l'argument 'transparency' pour indiquer quel indice de la palette
        # doit être considéré comme transparent lors de la sauvegarde en PNG.
        output_img.save(output_path, transparency=new_pixel_index) # new_pixel_index (223) sera l'indice transparent
        print(f"Image modifiée sauvegardée sous '{output_path}' avec les pixels de l'indice {old_pixel_index} déplacés vers {new_pixel_index}, et l'indice {new_pixel_index} défini comme transparent.")

    except FileNotFoundError:
        print(f"Erreur : Le fichier '{image_path}' n'a pas été trouvé.")
    except Exception as e:
        print(f"Une erreur inattendue est survenue : {e}")

# --- Utilisation du script ---
#if __name__ == "__main__":
#    input_image_file = "BUILD_LIGHTFACTORY.bmp"  # Remplacez par le chemin de votre image PNG 8 bits palettisée
#    output_image_file = "BUILD_LIGHTFACTORY.png" # Chemin pour sauvegarder l'image modifiée
#    #  Les pixels d'indice 0 seront déplacés vers l'indice 223.
#    #  La couleur à l'indice 223 dans la palette sera définie sur (0,0,0).
#    #  Et l'indice 223 sera l'indice de transparence pour le PNG.
#    process_image_for_transparency_and_index_swap(input_image_file, output_image_file, old_pixel_index=0, new_pixel_index=223)



repertoire_cible = "."  # Le répertoire actuel

contenu = os.listdir(repertoire_cible)
print(f"Contenu du répertoire '{repertoire_cible}':")
for element in contenu:
            # Vous pouvez ajouter une logique ici si vous voulez distinguer les fichiers des répertoires
            # Par exemple, pour lister uniquement les fichiers :
    chemin_complet = os.path.join(repertoire_cible, element)
    if os.path.isdir(chemin_complet):
        print(f"  Répertoire : {element}")
    elif os.path.isfile(chemin_complet):
        print(f"  Fichier : {element}")
        if "SHADOW" not in element and ".bmp" in element:
            print(f"  Fichier bmp : {element}")
            out = element[:-4]+".png"
            process_image_for_transparency_and_index_swap(element, out, old_pixel_index=0, new_pixel_index=223)
