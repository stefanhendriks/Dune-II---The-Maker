#include <vector>   // Pour utiliser std::vector
#include <string>   // Pour utiliser std::string
#include <iostream> // Pour l'exemple d'affichage

#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>
#include <string>
#include <iomanip>
#include <map>
#include <algorithm>
#include <memory>


std::string name = "sdl_headqrts.dat";

std::vector<std::string> tmpFiles = {
"01.bmp",
"02.bmp",
"03.bmp",
"04.bmp",
"05.bmp",
"06.bmp",
"07.bmp",
"08.bmp",
"09.bmp",
"10.bmp",
"11.bmp"
};

const int fileNameSize = 40;
const int titleSize = 4;    // "D2TM"
const int offsetSize = 4+4; // two uint32_t 
const int nbrFilesSize = 2; // one uint16_t
const int extensionSize = 4; // "WAV", "JPG", ...

struct FileInPack {
    std::string name;
    std::string fileId;
    std::string extension;
    uint32_t fileOffset;
    uint32_t fileSize;
};

class WriterPack
{
public:
    //! Create the archive skeleton
    WriterPack(const std::string &packName);
    ~WriterPack();
    //! add individual file fileName in archive and rename it by fileId 
    bool addFile(const std::string &fileName, const std::string &fileId);
    //! Create PackFile after add all files in archive
    bool writePackFilesOnDisk();
    //! for debug: display files in pack
    void displayPackFile();
private:
    void writeHeader();
    void writeFileLines();
    void copyFile();
    int numberFile = 0;
    std::unique_ptr<SDL_RWops, decltype(&SDL_RWclose)> wfp{nullptr, SDL_RWclose}; //wfp as writeFilePack
    std::vector<FileInPack> fileInPack;
};


WriterPack::WriterPack(const std::string &packName)
{
    wfp.reset(SDL_RWFromFile(packName.c_str(), "wb"));
}

WriterPack::~WriterPack()
{
    fileInPack.clear();
}

bool WriterPack::addFile(const std::string &fileName, const std::string &fileId)
{
    SDL_RWops *file = SDL_RWFromFile(fileName.c_str(),"rb");
    if (file!=nullptr) {
       
        FileInPack tmp;
        tmp.name = fileName;
        tmp.fileId = fileId;
        std::string ext = fileName.substr(fileName.find_last_of('.') + 1);
        std::transform(ext.begin(), ext.end(), ext.begin(), ::toupper);
        tmp.extension = ext.substr(0, 3); 
        tmp.fileSize = SDL_RWsize(file);
        tmp.fileOffset = 0;
        fileInPack.push_back(tmp);

        SDL_RWclose(file);
        return true;
    } else
        return false;
}

void WriterPack::writeHeader()
{
	const char *str = "D2TM";
    size_t len = SDL_strlen(str);
    if (SDL_RWwrite(wfp.get(), str, 1, len) != len) {
        printf("Couldn't fully write string\n");
    }
    u_int16_t nbFiles = fileInPack.size();
    SDL_RWwrite(wfp.get(), reinterpret_cast<const char*>(&nbFiles), sizeof(u_int16_t), 1);
}


void WriterPack::writeFileLines()
{
    uint32_t offset = 0;
    for (const auto& tmp : fileInPack) {
        // Create a temporary buffer to group the data
        char buffer[fileNameSize + extensionSize + sizeof(uint32_t) + sizeof(uint32_t)] = {0};
        // Copy fileId to buffer (limited to fileNameSize)
        strncpy(buffer, tmp.fileId.c_str(), fileNameSize);
        // Copy extension to buffer (limited to extensionSize)
        strncpy(buffer + fileNameSize, tmp.extension.c_str(), extensionSize);
        // Copy offset into buffer
        memcpy(buffer + fileNameSize + extensionSize, &offset, sizeof(uint32_t));
        // Copy fileSize to buffer
        memcpy(buffer + fileNameSize + extensionSize + sizeof(uint32_t), &tmp.fileSize, sizeof(uint32_t));
        // Write the buffer in one operation
        if (SDL_RWwrite(wfp.get(), buffer, 1, sizeof(buffer)) != sizeof(buffer)) {
            std::cerr << "Failed to write file line for: " << tmp.fileId << std::endl;
        }
        // Update the offset for the next file
        offset += tmp.fileSize;
    }
}

void WriterPack::displayPackFile()
{
    std::cout << "------------------------------" << std::endl;
    std::cout << "File(s) stored in archive " << std::endl;
    std::cout << "[fileId] -> [extension] -> size" << std::endl;
    std::cout << "------------------------------" << std::endl;
    for (const auto& tmp : fileInPack) {
        std::cout << "\t[" << tmp.fileId << "] -> [" << tmp.extension << "] -> " << std::setw(8) << tmp.fileSize << std::endl;
    }
    std::cout << "EOF" << std::endl;
}

void WriterPack::copyFile()
{
    for (const auto& tmp : fileInPack) {
        std::unique_ptr<SDL_RWops, decltype(&SDL_RWclose)> wf(SDL_RWFromFile(tmp.name.c_str(), "rb"), SDL_RWclose);
        if (!wf) {
            std::cerr << "Failed to open file: " << tmp.name << " - " << SDL_GetError() << std::endl;
            continue; // Passer au fichier suivant
        }
        Sint64 res_size = SDL_RWsize(wf.get());
        if (res_size <= 0) {
            std::cerr << "Invalid file size for: " << tmp.name << std::endl;
            continue;
        }

        std::vector<char> buffer(res_size);
        Sint64 nb_read = SDL_RWread(wf.get(), buffer.data(), 1, res_size);
        if (nb_read != res_size) {
            std::cerr << "Failed to read file: " << tmp.name << std::endl;
            continue;
        }

        Sint64 nb_written = SDL_RWwrite(wfp.get(), buffer.data(), 1, res_size);
        if (nb_written != res_size) {
            std::cerr << "Failed to write file: " << tmp.name << std::endl;
        }
    }
}

bool WriterPack::writePackFilesOnDisk()
{
    writeHeader();
    writeFileLines();
    copyFile();
    displayPackFile();
    return true;
}


int main(int argc, char ** argv)
{
    // First we create a pak file from scratch
        // write pak file.
    	WriterPack test(name);
        //
        for (const auto &file : tmpFiles) {
            // remove the extension from the file name
            std::string fileId = file.substr(0, file.find_last_of('.'));
            // add the file to the pack

            if (!test.addFile(file, fileId)) {
                std::cerr << "Failed to add file: " << file << std::endl;
            }
        }
        //
        test.writePackFilesOnDisk();

        test.displayPackFile();
    
        return 0;
}
