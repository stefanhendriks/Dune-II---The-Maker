from PIL import Image

def apply_dynamic_transparency(image_path, output_path):
    """
    Applies dynamic transparency to an image:
    - Black pixels become fully transparent.
    - Darker shades of black become increasingly transparent.
    - Other colors remain opaque, but their black component contributes to transparency.

    Args:
        image_path (str): The path to the input image (e.g., 'input_image.png').
        output_path (str): The path where the transparent image will be saved
                           (e.g., 'output_image_transparent.png').
    """
    try:
        # Open the image
        img = Image.open(image_path)

        # Convert the image to RGBA if it's not already.
        # This adds an alpha channel if it doesn't exist.
        if img.mode != 'RGBA':
            img = img.convert('RGBA')

        # Get pixel data
        pixels = img.load()
        width, height = img.size

        for x in range(width):
            for y in range(height):
                r, g, b, a = pixels[x, y]

                # Calculate "darkness" or "blackness" of the pixel.
                # A simple average of R, G, B can represent overall brightness.
                # The lower the value, the darker the pixel.
                # We normalize it to a 0-255 range, where 0 is black and 255 is white.
                brightness = (r + g + b) // 3

                # Determine the new alpha value.
                # If brightness is 0 (pure black), alpha should be 0 (fully transparent).
                # If brightness is 255 (pure white), alpha should be 255 (fully opaque).
                # We want a reverse relationship for transparency:
                # The darker (lower brightness), the *more* transparent (lower alpha).
                # So, alpha = brightness.
                # We can clamp the minimum alpha to avoid making non-black colors too transparent.
                new_alpha = brightness

                # Ensure the new_alpha is within the valid range (0-255)
                new_alpha = max(0, min(255, new_alpha))

                # Update the pixel with the new alpha value
                pixels[x, y] = (r, g, b, new_alpha)

        # Save the modified image
        img.save(output_path)
        print(f"Image successfully converted with transparency and saved to {output_path}")

    except FileNotFoundError:
        print(f"Error: The image file '{image_path}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    input_image_file = 'OBJECT_BOOM04.bmp'
    output_image_file = 'OBJECT_BOOM04.png'
    apply_dynamic_transparency(input_image_file, output_image_file)
