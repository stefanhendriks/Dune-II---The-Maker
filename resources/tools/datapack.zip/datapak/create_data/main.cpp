#include <vector>   // Pour utiliser std::vector
#include <string>   // Pour utiliser std::string
#include <iostream> // Pour l'exemple d'affichage
#include <string>
#include <iostream>
#include <iomanip>
#include <map>
#include <vector>
#include <algorithm>
#include <memory>

#include <SDL2/SDL.h>

std::vector<std::string> tmpFiles = {
"ATTACK_INDICATOR.png",
"BUILD_BARRACKS.png",
"BUILD_BARRACKS_SHADOW.png",
"BUILD_CONSTYARD.png",
"BUILD_CONSTYARD_SHADOW.png",
"BUILD_HEAVYFACTORY.png",
"BUILD_HEAVYFACTORY_FLASH.png",
"BUILD_HEAVYFACTORY_SHADOW.png",
"BUILD_HIGHTECH.png",
"BUILD_HIGHTECH_SHADOW.png",
"BUILD_IX.png",
"BUILD_IX_SHADOW.png",
"BUILD_LIGHTFACTORY.png",
"BUILD_LIGHTFACTORY_FLASH.png",
"BUILD_LIGHTFACTORY_SHADOW.png",
"BUILD_PALACE.png",
"BUILD_PALACE_SHADOW.png",
"BUILD_PRE_1X1.png",
"BUILD_PRE_1X1_SHADOW.png",
"BUILD_PRE_2X2.png",
"BUILD_PRE_2X2_SHADOW.png",
"BUILD_PRE_3X2.png",
"BUILD_PRE_3X2_SHADOW.png",
"BUILD_PRE_3X3.png",
"BUILD_PRE_3X3_SHADOW.png",
"BUILD_PRE_CONST.png",
"BUILD_RADAR.png",
"BUILD_RADAR_SHADOW.png",
"BUILD_REFINERY.png",
"BUILD_REFINERY_SHADOW.png",
"BUILD_REPAIR.png",
"BUILD_REPAIR_SHADOW.png",
"BUILD_RTURRET.png",
"BUILD_RTURRET_SHADOW.png",
"BUILD_SILO.png",
"BUILD_SILO_SHADOW.png",
"BUILD_STARPORT.png",
"BUILD_STARPORT_SHADOW.png",
"BUILD_TURRET.png",
"BUILD_TURRET_SHADOW.png",
"BUILD_WINDTRAP.png",
"BUILD_WINDTRAP_SHADOW.png",
"BUILD_WOR.png",
"BUILD_WOR_SHADOW.png",
"BUILDING_FLAG_LARGE.png",
"BUILDING_FLAG_SMALL.png",
"BULLET_DOT_LARGE.png",
"BULLET_DOT_MEDIUM.png",
"BULLET_DOT_SMALL.png",
"BULLET_PUF.png",
"BULLET_ROCKET_LARGE.png",
"BULLET_ROCKET_NORMAL.png",
"BULLET_ROCKET_SMALL.png",
"CREDITS_0.png",
"CREDITS_1.png",
"CREDITS_2.png",
"CREDITS_3.png",
"CREDITS_4.png",
"CREDITS_5.png",
"CREDITS_6.png",
"CREDITS_7.png",
"CREDITS_8.png",
"CREDITS_9.png",
"CREDITS_NONE.png",
"EXPLOSION_BULLET.png",
"EXPLOSION_FIRE.png",
"EXPLOSION_GAS.png",
"EXPLOSION_ORNI.png",
"EXPLOSION_ROCKET.png",
"EXPLOSION_ROCKET_SMALL.png",
"EXPLOSION_SQUISH01.png",
"EXPLOSION_SQUISH02.png",
"EXPLOSION_SQUISH03.png",
"EXPLOSION_STRUCTURE01.png",
"EXPLOSION_STRUCTURE02.png",
"EXPLOSION_TANK_ONE.png",
"EXPLOSION_TANK_TWO.png",
"EXPLOSION_TRIKE.png",
"FOCUS.png",
"MOUSE_ATTACK.png",
"MOUSE_DOWN.png",
"MOUSE_FORBIDDEN.png",
"MOUSE_LEFT.png",
"MOUSE_MOVE.png",
"MOUSE_NORMAL.png",
"MOUSE_PICK.png",
"MOUSE_RALLY.png",
"MOUSE_REPAIR.png",
"MOUSE_RIGHT.png",
"MOUSE_UP.png",
"MOVE_INDICATOR.png",
"OBJECT_BOOM01.png",
"OBJECT_BOOM02.png",
"OBJECT_BOOM03.png",
"OBJECT_BOOM04.png",
"OBJECT_CARRYPUFF.png",
"OBJECT_DEADINF01.png",
"OBJECT_DEADINF02.png",
"OBJECT_SIEGEDIE.png",
"OBJECT_SIEGESHOOT.png",
"OBJECT_SMOKE.png",
"OBJECT_SMOKE_SHADOW.png",
"OBJECT_STAR_01.png",
"OBJECT_STAR_02.png",
"OBJECT_STAR_03.png",
"OBJECT_TANKSHOOT.png",
"OBJECT_WORMEAT.png",
"OBJECT_WORMTRAIL.png",
"PALETTE_D2TM.png",
"PLACE_SLAB1.png",
"PLACE_SLAB4.png",
"PLACE_WALL.png",
"SHOOT_TANK.png",
"SHROUD.png",
"SHROUD_SHADOW.png",
"SMUDGE.png",
"SYMB_PICKMEUP.png",
"TERRAIN_BLOOM.png",
"TERRAIN_HILL.png",
"TERRAIN_MOUNTAIN.png",
"TERRAIN_ROCK.png",
"TERRAIN_SAND.png",
"TERRAIN_SLAB.png",
"TERRAIN_SPICE.png",
"TERRAIN_SPICEHILL.png",
"TERRAIN_WALL.png",
"TRACK_DIA.png",
"TRACK_DIA2.png",
"TRACK_HOR.png",
"TRACK_VER.png",
"UNIT_CARRYALL.png",
"UNIT_CARRYALL_SHADOW.png",
"UNIT_DEVASTATOR.png",
"UNIT_DEVASTATOR_SHADOW.png",
"UNIT_DEVIATOR.png",
"UNIT_FRIGATE.png",
"UNIT_FRIGATE_SHADOW.png",
"UNIT_HARVESTER.png",
"UNIT_HARVESTER_SHADOW.png",
"UNIT_LAUNCHER.png",
"UNIT_LAUNCHER_SHADOW.png",
"UNIT_MCV.png",
"UNIT_MCV_SHADOW.png",
"UNIT_ORNITHOPTER.png",
"UNIT_ORNITHOPTER_SHADOW.png",
"UNIT_QUAD.png",
"UNIT_QUAD_SHADOW.png",
"UNIT_RAIDER.png",
"UNIT_RAIDER_SHADOW.png",
"UNIT_SABOTEUR.png",
"UNIT_SANDWORM.png",
"UNIT_SIEGEBASE.png",
"UNIT_SIEGEBASE_SHADOW.png",
"UNIT_SIEGETOP.png",
"UNIT_SINGLEFREMEN.png",
"UNIT_SOLDIER.png",
"UNIT_SOLDIERS.png",
"UNIT_SONICTANK.png",
"UNIT_SONICTANK_SHADOW.png",
"UNIT_TANKBASE.png",
"UNIT_TANKBASE_SHADOW.png",
"UNIT_TANKTOP.png",
"UNIT_TRIKE.png",
"UNIT_TRIKE_SHADOW.png",
"UNIT_TRIPLEFREMEN.png",
"UNIT_TROOPER.png",
"UNIT_TROOPERS.png"
};

struct FileInPack {
    std::string name;
    std::string fileId;
    std::string extension;
    uint32_t fileOffset;
    uint32_t fileSize;
};

const int fileNameSize = 40;
const int titleSize = 4;    // "D2TM"
const int offsetSize = 4+4; // two uint32_t 
const int nbrFilesSize = 2; // one uint16_t
const int extensionSize = 4; // "WAV", "JPG", ...


class WriterPack
{
public:
    //! Create the archive skeleton
    WriterPack(const std::string &packName);
    ~WriterPack();
    //! add individual file fileName in archive and rename it by fileId 
    bool addFile(const std::string &fileName, const std::string &fileId);
    //! Create PackFile after add all files in archive
    bool writePackFilesOnDisk();
    //! for debug: display files in pack
    void displayPackFile();
private:
    void writeHeader();
    void writeFileLines();
    void copyFile();
    int numberFile = 0;
    std::unique_ptr<SDL_RWops, decltype(&SDL_RWclose)> wfp{nullptr, SDL_RWclose}; //wfp as writeFilePack
    std::vector<FileInPack> fileInPack;
};


WriterPack::WriterPack(const std::string &packName)
{
    wfp.reset(SDL_RWFromFile(packName.c_str(), "wb"));
}

WriterPack::~WriterPack()
{
    fileInPack.clear();
}

bool WriterPack::addFile(const std::string &fileName, const std::string &fileId)
{
    SDL_RWops *file = SDL_RWFromFile(fileName.c_str(),"rb");
    if (file!=nullptr) {
       
        FileInPack tmp;
        tmp.name = fileName;
        tmp.fileId = fileId;
        std::string ext = fileName.substr(fileName.find_last_of('.') + 1);
        std::transform(ext.begin(), ext.end(), ext.begin(), ::toupper);
        tmp.extension = ext.substr(0, 3); 
        tmp.fileSize = SDL_RWsize(file);
        tmp.fileOffset = 0;
        fileInPack.push_back(tmp);

        SDL_RWclose(file);
        return true;
    } else
        return false;
}

void WriterPack::writeHeader()
{
	const char *str = "D2TM";
    size_t len = SDL_strlen(str);
    if (SDL_RWwrite(wfp.get(), str, 1, len) != len) {
        printf("Couldn't fully write string\n");
    }
    u_int16_t nbFiles = fileInPack.size();
    SDL_RWwrite(wfp.get(), reinterpret_cast<const char*>(&nbFiles), sizeof(u_int16_t), 1);
}


void WriterPack::writeFileLines()
{
    uint32_t offset = 0;
    for (const auto& tmp : fileInPack) {
        // Create a temporary buffer to group the data
        char buffer[fileNameSize + extensionSize + sizeof(uint32_t) + sizeof(uint32_t)] = {0};
        // Copy fileId to buffer (limited to fileNameSize)
        strncpy(buffer, tmp.fileId.c_str(), fileNameSize);
        // Copy extension to buffer (limited to extensionSize)
        strncpy(buffer + fileNameSize, tmp.extension.c_str(), extensionSize);
        // Copy offset into buffer
        memcpy(buffer + fileNameSize + extensionSize, &offset, sizeof(uint32_t));
        // Copy fileSize to buffer
        memcpy(buffer + fileNameSize + extensionSize + sizeof(uint32_t), &tmp.fileSize, sizeof(uint32_t));
        // Write the buffer in one operation
        if (SDL_RWwrite(wfp.get(), buffer, 1, sizeof(buffer)) != sizeof(buffer)) {
            std::cerr << "Failed to write file line for: " << tmp.fileId << std::endl;
        }
        // Update the offset for the next file
        offset += tmp.fileSize;
    }
}

void WriterPack::displayPackFile()
{
    std::cout << "------------------------------" << std::endl;
    std::cout << "File(s) stored in archive " << std::endl;
    std::cout << "[fileId] -> [extension] -> size" << std::endl;
    std::cout << "------------------------------" << std::endl;
    for (const auto& tmp : fileInPack) {
        std::cout << "\t[" << tmp.fileId << "] -> [" << tmp.extension << "] -> " << std::setw(8) << tmp.fileSize << std::endl;
    }
    std::cout << "EOF" << std::endl;
}

void WriterPack::copyFile()
{
    for (const auto& tmp : fileInPack) {
        std::unique_ptr<SDL_RWops, decltype(&SDL_RWclose)> wf(SDL_RWFromFile(tmp.name.c_str(), "rb"), SDL_RWclose);
        if (!wf) {
            std::cerr << "Failed to open file: " << tmp.name << " - " << SDL_GetError() << std::endl;
            continue; // Passer au fichier suivant
        }
        Sint64 res_size = SDL_RWsize(wf.get());
        if (res_size <= 0) {
            std::cerr << "Invalid file size for: " << tmp.name << std::endl;
            continue;
        }

        std::vector<char> buffer(res_size);
        Sint64 nb_read = SDL_RWread(wf.get(), buffer.data(), 1, res_size);
        if (nb_read != res_size) {
            std::cerr << "Failed to read file: " << tmp.name << std::endl;
            continue;
        }

        Sint64 nb_written = SDL_RWwrite(wfp.get(), buffer.data(), 1, res_size);
        if (nb_written != res_size) {
            std::cerr << "Failed to write file: " << tmp.name << std::endl;
        }
    }
}

bool WriterPack::writePackFilesOnDisk()
{
    writeHeader();
    writeFileLines();
    copyFile();
    displayPackFile();
    return true;
}



int main(int argc, char ** argv)
{
    // First we create a pak file from scratch
        // write pak file.
    	WriterPack test("sdl_data.dat");
        //
        for (const auto &file : tmpFiles) {
            // remove the extension from the file name
            std::string fileId = file.substr(0, file.find_last_of('.'));
            // add the file to the pack

            if (!test.addFile(file, fileId)) {
                std::cerr << "Failed to add file: " << file << std::endl;
            }
        }
        //
        test.writePackFilesOnDisk();

        test.displayPackFile();
    
        return 0;
}
