#include <vector>   // Pour utiliser std::vector
#include <string>   // Pour utiliser std::string
#include <iostream> // Pour l'exemple d'affichage

#include <SDL2/SDL.h>
#include <SDL2/SDL_mixer.h>

#include "pack.h"

std::vector<std::string> tmpFiles = {
"BMP_D2TM.png",
"BMP_GAME_DUNE.png",
"BMP_GENERATING.png",
"BMP_GERALD_CANDYBAR_BALL.png",
"BMP_GERALD_CANDYBAR_BOTTOM.png",
"BMP_GERALD_CANDYBAR_PIECE.png",
"BMP_GERALD_CANDYBAR_TOP.png",
"BMP_GERALD_ICONLIST_BACKGROUND.png",
"BMP_GERALD_SIDEBAR_PIECE.png",
"BMP_GERALD_TOP_BAR.png",
"BMP_LOSING.png",
"BMP_SELECT_HOUSE_ATREIDES.png",
"BMP_SELECT_HOUSE_HARKONNEN.png",
"BMP_SELECT_HOUSE_ORDOS.png",
"BMP_SELECT_YOUR_HOUSE.png",
"BMP_TOPBAR_BACKGROUND.png",
"BMP_UNKNOWNMAP.png",
"BMP_WINNING.png",
"BTN_OPTIONS.png",
"BTN_ORDER.png",
"CREDITS_BAR.png",
"CREDITS_DUNE2_CORE_TEAM.png",
"D2TM_TITLE.png",
"GRID_0X0.png",
"GRID_1X1.png",
"GRID_2X2.png",
"GRID_3X2.png",
"GRID_3X3.png",
"HORIZONTAL_CANDYBAR.png",
"ICON_SPECIAL_FREMEN.png",
"ICON_SPECIAL_MISSILE.png",
"ICON_SPECIAL_SABOTEUR.png",
"ICON_STR_1SLAB.png",
"ICON_STR_4SLAB.png",
"ICON_STR_BARRACKS.png",
"ICON_STR_CONSTYARD.png",
"ICON_STR_HEAVYFACTORY.png",
"ICON_STR_HIGHTECH.png",
"ICON_STR_IX.png",
"ICON_STR_LIGHTFACTORY.png",
"ICON_STR_PALACE.png",
"ICON_STR_RADAR.png",
"ICON_STR_REFINERY.png",
"ICON_STR_REPAIR.png",
"ICON_STR_RTURRET.png",
"ICON_STR_SILO.png",
"ICON_STR_STARPORT.png",
"ICON_STR_TURRET.png",
"ICON_STR_WALL.png",
"ICON_STR_WINDTRAP.png",
"ICON_STR_WOR.png",
"ICON_UNIT_CARRYALL.png",
"ICON_UNIT_DEVASTATOR.png",
"ICON_UNIT_DEVIATOR.png",
"ICON_UNIT_FREMEN.png",
"ICON_UNIT_HARVESTER.png",
"ICON_UNIT_INFANTRY.png",
"ICON_UNIT_LAUNCHER.png",
"ICON_UNIT_MCV.png",
"ICON_UNIT_ORNITHOPTER.png",
"ICON_UNIT_QUAD.png",
"ICON_UNIT_RAIDER.png",
"ICON_UNIT_SABOTEUR.png",
"ICON_UNIT_SANDWORM.png",
"ICON_UNIT_SARDAUKAR.png",
"ICON_UNIT_SIEGETANK.png",
"ICON_UNIT_SOLDIER.png",
"ICON_UNIT_SONICTANK.png",
"ICON_UNIT_TANK.png",
"ICON_UNIT_TRIKE.png",
"ICON_UNIT_TROOPER.png",
"ICON_UNIT_TROOPERS.png",
"LIST_BTN_CONSTYARD.png",
"LIST_BTN_FACTORY.png",
"LIST_BTN_INFANTRY.png",
"LIST_BTN_PALACE.png",
"LIST_BTN_STARPORT.png",
"LIST_BTN_UPGRADE.png",
"MESSAGE_LEFT.png",
"MESSAGE_MIDDLE.png",
"MESSAGE_RIGHT.png",
"PAL_INTER.png",
"PROGRESS001.png",
"PROGRESS002.png",
"PROGRESS003.png",
"PROGRESS004.png",
"PROGRESS005.png",
"PROGRESS006.png",
"PROGRESS007.png",
"PROGRESS008.png",
"PROGRESS009.png",
"PROGRESS010.png",
"PROGRESS011.png",
"PROGRESS012.png",
"PROGRESS013.png",
"PROGRESS014.png",
"PROGRESS015.png",
"PROGRESS016.png",
"PROGRESS017.png",
"PROGRESS018.png",
"PROGRESS019.png",
"PROGRESS020.png",
"PROGRESS021.png",
"PROGRESS022.png",
"PROGRESS023.png",
"PROGRESS024.png",
"PROGRESS025.png",
"PROGRESS026.png",
"PROGRESS027.png",
"PROGRESS028.png",
"PROGRESS029.png",
"PROGRESS030.png",
"PROGRESS031.png",
"PROGRESS032.png",
"PROGRESSFIX.png",
"PROGRESSNA.png",
"READY01.png",
"READY02.png",
"STAT01.png",
"STAT02.png",
"STAT03.png",
"STAT04.png",
"STAT05.png",
"STAT06.png",
"STAT07.png",
"STAT08.png",
"STAT09.png",
"STAT10.png",
"STAT11.png",
"STAT12.png",
"STAT13.png",
"STAT14.png",
"STAT15.png",
"STAT16.png",
"STAT17.png",
"STAT18.png",
"STAT19.png",
"STAT20.png",
"STAT21.png",
"ICON_POWER.png",
"ICON_POWER_HIGH.png",
"ICON_SOLARIS_LOW.png",
"ICON_SOLARIS.png",
"ICON_SOLARIS_FULL.png"
};


int main(int argc, char ** argv)
{
    // First we create a pak file from scratch
        // write pak file.
    	WriterPack test("sdl_inter.dat");
        //
        for (const auto &file : tmpFiles) {
            // remove the extension from the file name
            std::string fileId = file.substr(0, file.find_last_of('.'));
            // add the file to the pack

            if (!test.addFile(file, fileId)) {
                std::cerr << "Failed to add file: " << file << std::endl;
            }
        }
        //
        test.writePackFilesOnDisk();

        test.displayPackFile();
    
        return 0;
}
