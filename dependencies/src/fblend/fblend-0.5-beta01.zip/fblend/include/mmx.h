#define FBLEND_MMX 
