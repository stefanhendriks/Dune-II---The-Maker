Copy all these files in your LIB directory of your MSVC version.

NOTE: Be sure you get the 3rdparty DLL package as well
NOTE: Be sure you get the 3rdparty header files as well