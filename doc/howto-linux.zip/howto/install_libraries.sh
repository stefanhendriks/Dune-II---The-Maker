#!/bin/bash

fblend_install () {
echo "### Installing fblend"
unzip -a fblend-0.5-beta01.zip &&
patch -p0 < fblend.patch &&
cd fblend &&
bash fix.sh unix &&
make &&
su -c "make install" &&
cd .. &&
return 0

return 1
}

allegromp3_install () {
echo "### Installing allegromp3"
unzip almp3.zip -d almp3 &&
patch -p0 < almp3.patch &&
cd almp3 &&
make &&
su -c "make install" &&
cd .. &&
return 0
 
return 1
}

allegrofont_install () {
echo "### Installing allegrofont"
unrar x AlFont206.rar &&
patch -p0 < alfont.patch &&
cd AlFont &&
make &&
su -c "make install" &&
cd .. &&
return 0

return 1
}

raknet_install () {
echo "### Installing RakNet"
unzip RakNet.zip -d raknet &&
patch -p0 < raknet.patch &&
cd raknet &&
make &&
su -c "make install" &&
cd .. &&
return 0
 
return 1
}

fblend_install && allegromp3_install && allegrofont_install && raknet_install